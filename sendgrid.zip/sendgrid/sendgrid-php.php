<?php

header("Access-Control-Allow-Origin: https://sendgrid.api-docs.io");

require 'vendor/autoload.php';

// If you are not using Composer
// require("path/to/sendgrid-php/sendgrid-php.php");

$from = new SendGrid\Email("Example User", "parisutham22@gmail.com");
$subject = "Subject";
$to = new SendGrid\Email("Example User", "parisutham22@gmail.com");
$content = new SendGrid\Content("text/plain", "and easy to do anywhere, even with PHP");
$mail = new SendGrid\Mail($from, $subject, $to, $content);

$apiKey = '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';
$sg = new \SendGrid($apiKey);

$response = $sg->client->mail()->send()->post($mail);
print_r($response);exit;
echo $response->statusCode();

exit;
?>